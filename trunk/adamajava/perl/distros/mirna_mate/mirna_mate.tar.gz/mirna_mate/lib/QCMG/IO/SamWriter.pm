package QCMG::IO::SamWriter;


###########################################################################
#
#  Module:   QCMG::IO::SamWriter
#  Creator:  John V Pearson
#  Created:  2009-01-22
#
#  Creates v0.1.2 SAM file (1000 Genomes) to hold sequencing read
#  alignment records.
#
#  $Id: $
#
###########################################################################

use Data::Dumper;

sub new {
    my $class = shift;
    my %params = @_;

    die "SamWriter:new() requires a filename parameter" 
        unless (exists $params{filename} and defined $params{filename});

    my $self = { filename        => $params{filename},
                 sam_version     => '0.1.2',
                 sort_order      => 'unsorted',
                 group_order     => 'none',
                 p_name          => ($params{p_name} ?
                                     $params{p_name} : ''),
                 p_cmdline       => ($params{p_cmdline} ?
                                     $params{p_cmdline} : ''),
                 p_version       => ($params{p_version} ?
                                     $params{p_version} : 0),
                 description     => ($params{description} ?
                                     $params{description} : 0),
                 verbose         => ($params{verbose} ?
                                     $params{verbose} : 0),
               };

    bless $self, $class;

    # Open file and make sure it is writable
    my $fh = IO::File->new( $params{filename}, 'w' );
    die 'Unable to open ', $params{filename}, "for writing: $!"
        unless defined $fh;

    $self->filehandle( $fh );
    return $self;
}


sub filename {
    my $self = shift;
    return $self->{filename} = shift if @_;
    return $self->{filename};
}

sub filehandle {
    my $self = shift;
    return $self->{filehandle} = shift if @_;
    return $self->{filehandle};
}

sub sam_version {
    my $self = shift;
    return $self->{sam_version};
}

sub p_name {
    my $self = shift;
    return $self->{p_name};
}

sub p_cmdline {
    my $self = shift;
    return $self->{p_cmdline};
}

sub p_version {
    my $self = shift;
    return $self->{p_version};
}

sub group_order {
    my $self = shift;
    return $self->{group_order} = shift if @_;
    return $self->{group_order};
}


sub sort_order {
    my $self = shift;

    if (@_) {
        my $order = lc( shift );
        if ($order =~ /unsorted/i or
            $order =~ /queryname/i or
            $order =~ /coordinate/i ) {
            $self->{sort_order} = lc( $order );
        }
        else {
            die "Invalid value [$order] supplied to sort_order(). ",
                "Valid values are: unsorted, queryname, coordinate\n";
        }
    }

    return $self->{sort_order};
}


sub header {
    my $self = shift;

    my $header = '@HD' ."\t" . 'VN:' . $self->sam_version . "\t" .
                               'SO:' . $self->sort_order . "\t" .
                               'GO:' . $self->group_order . "\n";
    $header .=  '@PG' . "\t" . $self->program . "\n";

    return $header;
}


sub program {
    my $self = shift;

    my $program = 'ID:' . $self->p_name . "\t" .
                  'VN:' . $self->p_version  . "\t" .
                  'CL:' . $self->p_cmdline;
    return $program;
}


sub write {
    my $self = shift;
    my $line = shift;

    $self->filehandle->print( $line );
}

1;

__END__


=head1 NAME

QCMG::IO::SamWriter - SAM file IO


=head1 SYNOPSIS

 use QCMG::IO::SamWriter;


=head1 DESCRIPTION

This module provides an interface for reading and writing SAM files.


=head1 AUTHORS

John Pearson L<mailto:j.pearson@uq.edu.au>


=head1 VERSION

$Id: $


=head1 COPYRIGHT

This software is copyright 2010 by the Queensland Centre for Medical
Genomics. All rights reserved.  This License is limited to, and you
may use the Software solely for, your own internal and non-commercial
use for academic and research purposes. Without limiting the foregoing,
you may not use the Software as part of, or in any way in connection with 
the production, marketing, sale or support of any commercial product or
service or for any governmental purposes.  For commercial or governmental 
use, please contact licensing\@qcmg.org.

In any work or product derived from the use of this Software, proper 
attribution of the authors as the source of the software or data must be 
made.  The following URL should be cited:

  http://bioinformatics.qcmg.org/software/

=cut
