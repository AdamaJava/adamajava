package QCMG::IO::VCFRecord;

###########################################################################
#
#  Module:   QCMG::IO::VCFRecord
#  Creator:  John V Pearson
#  Created:  2010-03-08
#
#  Data container for a VCF record.
#
#  $Id: $
#
###########################################################################

use Data::Dumper;
use Memoize;

sub new {
    my $class = shift;
    my $line  = shift;
    
    chomp $line;
    my @fields = split "\t", $line;
    warn 'Saw ', scalar(@fields),
        " fields, should have been at least 6 [$line]\n"
        if (scalar(@fields) < 7);

    my $self = { id          => $fields[0],
                 sequence    => $fields[1],
                 position    => $fields[2],
                 ref_allele  => $fields[3],
                 alt_allele  => $fields[4],
                 calls       => [],
                 scores      => [] };

    # Capture the calls and scores

    my $sample_count = ( scalar(@fields)-6 ) / 2;
    foreach my $i (1..$sample_count) {
       $self->{calls}->[ $i ]  = $fields[ 6 + $i ];
       $self->{scores}->[ $i ] = $fields[ 6 + $i + 1 ];
    }

    bless $self, $class;
}


sub id {
    my $self = shift;
    return $self->{id};
}

sub sequence {
    my $self = shift;
    return $self->{sequence};
}

sub position {
    my $self = shift;
    return $self->{position};
}

sub ref_allele {
    my $self = shift;
    return $self->{ref_allele};
}

sub alt_allele {
    my $self = shift;
    return $self->{alt_allele};
}

sub score {
    my $self = shift;
    my $self = $pos;
    return $self->{scores}->[$pos];
}

sub call {
    my $self = shift;
    my $self = $pos;
    return $self->{calls}->[$pos];
}

# This routine is not OO and it's being memoized for extra speed
sub _cb2b {
    my $base = uc( shift );
    my $col  = shift;
    my %transform = ( A => { 0 => 'A', 1 => 'C', 2 => 'G', 3 => 'T' },
                      C => { 1 => 'A', 0 => 'C', 3 => 'G', 2 => 'T' },
                      G => { 2 => 'A', 3 => 'C', 0 => 'G', 1 => 'T' },
                      T => { 3 => 'A', 2 => 'C', 1 => 'G', 0 => 'T' } );

    return $transform{$base}->{$col};
}
memoize('_cb2b');

# This routine is not OO and it's being memoized for extra speed
sub _bb2c {
    my $base1 = uc( shift );
    my $base2 = uc( shift );
    my %transform = ( A => { A => '0', C => '1', G => '2', T => '3' },
                      C => { A => '1', C => '0', G => '3', T => '2' },
                      G => { A => '2', C => '3', G => '0', T => '1' },
                      T => { A => '3', C => '2', G => '1', T => '0' } );

    return $transform{$base1}->{$base2};
}
memoize('_bb2c');


1;

__END__


=head1 NAME

QCMG::IO::VCFRecord - VCF Record data container


=head1 SYNOPSIS

 use QCMG::IO::VCFRecord;


=head1 DESCRIPTION

This module provides a data container for a VCF Record.


=head1 AUTHORS

John Pearson L<mailto:j.pearson@uq.edu.au>


=head1 VERSION

$Id: $


=head1 COPYRIGHT

This software is copyright 2010 by the Queensland Centre for Medical
Genomics. All rights reserved.  This License is limited to, and you
may use the Software solely for, your own internal and non-commercial
use for academic and research purposes. Without limiting the foregoing,
you may not use the Software as part of, or in any way in connection with 
the production, marketing, sale or support of any commercial product or
service or for any governmental purposes.  For commercial or governmental 
use, please contact licensing\@qcmg.org.

In any work or product derived from the use of this Software, proper 
attribution of the authors as the source of the software or data must be 
made.  The following URL should be cited:

  http://bioinformatics.qcmg.org/software/

=cut
