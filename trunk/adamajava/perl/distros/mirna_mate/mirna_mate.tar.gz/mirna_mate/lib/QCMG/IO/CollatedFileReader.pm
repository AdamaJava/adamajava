package QCMG::IO::CollatedFileReader;

###########################################################################
#
#  Module:   QCMG::IO::CollatedFileReader
#  Creator:  John V Pearson
#  Created:  2010-02-13
#
#  Reads a collated as created by RNA-Mate or X-Mate.  A collated file
#  is very similar to the .ma matches file created by the ABI
#  corona-lite/mapreads pipelein except that the match location is
#  listed in the defline in a slightly different way.  Both files are
#  very similar to a multiple sequence FASTA file, i.e. the matches
#  appear as multiepl sequence records where each sequence has a defline
#  followed by the sequence matched.
#
#  $Id: $
#
###########################################################################

use Data::Dumper;
use Carp qw( confess );

sub new {
    my $class = shift;
    my %params = @_;

    confess "CollatedFileReader->new() requires a file parameter" 
        unless (exists $params{file} and defined $params{file});

    my $self  = { file         => $params{file},
                  verbose      => ($params{verbose} ? $params{verbose} : 0),
                  _defline     => '',
                  _recctr      => 0,
                  CreationTime => localtime().'',
                  Version      => $VERSION, 
                };

    bless $self, $class;
}

sub verbose {
    my $self = shift;
    return $self->{verbose};
}

sub file {
    my $self = shift;
    return $self->{file};
}

sub sequences {
    my $self = shift;
    return @{ $self->{sequences} };
}

sub creation_time {
    my $self = shift;
    return $self->{'CreationTime'};
}

sub creator_module_version {
    my $self = shift;
    return $self->{'Version'};
}


sub parse_file {
    my $self = shift;

    my $fh = IO::File->new( $self->file, 'r' );
    confess 'Unable to open FASTA file [', $self->file, "] for reading: $!"
        unless defined $fh;

    # Process FASTA string in case it contains multiple sequences
    print 'processing FASTA file [', $self->file, "]\n"
        if $self->verbose;

    my @seqs    = ();
    my $defline = '';
    my $seq     = '';

    while (my $line = $fh->getline) {
        chomp $line;
        $line =~ s/\s+$//;        # trim trailing spaces
        next if ($line =~ /^#/);  # skip comments
        next unless $line;        # skip blank lines

        if ($line =~ /^>/) {
            if ($defline) {
                push @seqs, Bio::TGen::Util::Sequence->new(
                                defline  => $defline,
                                sequence => $seq,
                                verbose  => $self->verbose );
            }
            $defline = $line;
            $seq     = '';
        }
        else {
            $seq .= $line;
        }
    }

}


sub parse_file {
    my $self = shift;

    my $fh = IO::File->new( $self->file, 'r' );
    confess 'Unable to open FASTA file [', $self->file, "] for reading: $!"
        unless defined $fh;

    # Process FASTA string in case it contains multiple sequences
    print 'processing FASTA file [', $self->file, "]\n"
        if $self->verbose;

    my @seqs    = ();
    my $defline = '';
    my $seq     = '';

    while (my $line = $fh->getline) {
        chomp $line;
        $line =~ s/\s+$//;        # trim trailing spaces
        next if ($line =~ /^#/);  # skip comments
        next unless $line;        # skip blank lines

        if ($line =~ /^>/) {
            if ($defline) {
                push @seqs, Bio::TGen::Util::Sequence->new(
                                defline  => $defline,
                                sequence => $seq,
                                verbose  => $self->verbose );
            }
            $defline = $line;
            $seq     = '';
        }
        else {
            $seq .= $line;
        }
    }

    # Catch last sequence
    if ($defline) {
        push @seqs, Bio::TGen::Util::Sequence->new(
                        defline  => $defline,
                        sequence => $seq,
                        verbose  => $self->verbose );
    }

    $self->{sequences} = \@seqs;
}

sub write_seqs {
    my $self = shift;
    foreach my $seq ($self->sequences) {
       $seq->write_FASTA_file;
    }
}

1;
__END__


=head1 NAME

QCMG::IO::CollatedFileReader - Read X-Mate collated alignment files


=head1 SYNOPSIS

 use QCMG::IO::CollatedFileReader;


=head1 DESCRIPTION

This module provides an interface for reading and writing collated
alignment files as created by RNA-Mate and X-Mate. 


=head1 AUTHORS

John Pearson L<mailto:j.pearson@uq.edu.au>


=head1 VERSION

$Id: $


=head1 COPYRIGHT

This software is copyright 2010 by the Queensland Centre for Medical
Genomics. All rights reserved.  This License is limited to, and you
may use the Software solely for, your own internal and non-commercial
use for academic and research purposes. Without limiting the foregoing,
you may not use the Software as part of, or in any way in connection with 
the production, marketing, sale or support of any commercial product or
service or for any governmental purposes.  For commercial or governmental 
use, please contact licensing\@qcmg.org.

In any work or product derived from the use of this Software, proper 
attribution of the authors as the source of the software or data must be 
made.  The following URL should be cited:

  http://bioinformatics.qcmg.org/software/

=cut
