package QCMG::IO::SamRecord;

###########################################################################
#
#  Module:   QCMG::IO::SamRecord
#  Creator:  John V Pearson
#  Created:  2009-02-12
#
#  Data container for a SAM v0.1.2 record.
#
#  $Id: $
#
###########################################################################

use Data::Dumper;
use Memoize;

sub new {
    my $class  = shift;
    my %params = @_;

    my $self = { qname   => '',
                 flag    => unpack("S", pack("B*",'0'x16)),  # 16 bits zerod
                 rname   => '',
                 pos     => 0,
                 mapq    => 255,
                 cigar   => '',
                 mrnm    => '',
                 mpos    => 0,
                 isize   => 0,
                 seq     => '',
                 qual    => '',
                 tags    => {} };

    bless $self, $class;


    # If GFF record passed in, populate SAM record
    $self->from_gff( $params{gff} ) if $params{gff};

    return $self;
}


sub qname {
    my $self = shift;
    return $self->{qname} = shift if @_;
    return $self->{qname};
}

sub flag {
    my $self = shift;
    return $self->{flag} = shift if @_;
    return $self->{flag};
}

sub rname {
    my $self = shift;
    return $self->{rname} = shift if @_;
    return $self->{rname};
}

sub pos {
    my $self = shift;
    return $self->{pos} = shift if @_;
    return $self->{pos};
}

sub mapq {
    my $self = shift;
    return $self->{mapq} = shift if @_;
    return $self->{mapq};
}

sub cigar {
    my $self = shift;
    return $self->{cigar} = shift if @_;
    return $self->{cigar};
}

sub mrnm {
    my $self = shift;
    return $self->{mrnm} = shift if @_;
    return $self->{mrnm};
}

sub mpos {
    my $self = shift;
    return $self->{mpos} = shift if @_;
    return $self->{mpos};
}

sub isize {
    my $self = shift;
    return $self->{isize} = shift if @_;
    return $self->{isize};
}

sub seq {
    my $self = shift;
    return $self->{seq} = shift if @_;
    return $self->{seq};
}

sub qual {
    my $self = shift;
    return $self->{qual} = shift if @_;
    return $self->{qual};
}

sub tag {
    my $self = shift;
    my $type = shift;
    return $self->{tags}->{$type} = shift if @_;
    return $self->{tags}->{$type};
}


sub tags {
    my $self = shift;
    return $self->{tags};
}


sub tags_as_array {
    my $self = shift;
    return values %{ $self->{tags} };
}


# This routine is not OO and it's being memoized for extra speed
sub _bb2c {
    my $base1 = uc( shift );
    my $base2 = uc( shift );
    my %transform = ( A => { A => '0', C => '1', G => '2', T => '3' },
                      C => { A => '1', C => '0', G => '3', T => '2' },
                      G => { A => '2', C => '3', G => '0', T => '1' },
                      T => { A => '3', C => '2', G => '1', T => '0' } );

    return $transform{$base1}->{$base2};
}
memoize('_bb2c');


sub from_gff {
    my $self = shift;
    my $gff  = shift;

    # Process ID including removal of trailing _F3 / _R3 from IDs
    my $qname = $gff->seqname;
    $qname =~ s/_[FR]3$//;
    $self->qname( $qname );

    #print Dumper $self->flag, pack("S", $self->flag);

    # Set appropriate bits in flag
    my $flag = pack("S", $self->flag);
    vec( $flag, 0, 1 ) = 1 if ($gff->matepair);      # mate pair library
    vec( $flag, 4, 1 ) = 1 if ($gff->strand eq '-'); # match on - strand
    vec( $flag, 6, 1 ) = 1;                          # first read
    $self->flag( unpack("S",$flag) );

    #print Dumper $self->flag, unpack("S",$flag);

    # In the GFF sequences are only identified by number
    $self->rname( 'seq_' . $gff->attrib('i') );

    my $bquals = $gff->color_quality_to_base_quality;
    if ($gff->strand eq '-') {
       my @bquals = reverse split( //, $bquals );
       $bquals = join( '', @bquals );
    }
    $self->qual( $bquals );

    $self->pos( $gff->start );
    $self->cigar( length( $gff->attrib('b') ) .'M' );

    # Set sequence and work out MD descriptor as follows:
    # 1. $self->seq = AB "believed" sequence (GFF b= attrib), revcomp if
    #    match is on - strand
    # 2. To get reference, fix original color based on r= attrib,
    #    convert to base space and revcomp if match is on - strand
    # 3. Compare sequences from 1. and 2. and code delta in MD format

    if ($gff->strand eq '-') {
        $self->seq( uc( $gff->revcomp( $gff->attrib('b') ) ) );
        my $refr_seq = $gff->revcomp( $gff->color_fixed_to_base );
        $self->tag( 'MD', 'MD:Z:'. $self->MD( $self->seq, $refr_seq ) );
    }
    else {
        $self->seq( uc( $gff->attrib('b') ) );
        my $refr_seq = $gff->color_fixed_to_base;
        $self->tag( 'MD', 'MD:Z:'. $self->MD( $self->seq, $refr_seq ) );
    }

    # Add 33 to all qualities and ASCII-ize
    my @cquals = map { chr(33+$_) }
                 split(',',$gff->attrib('q'));

    $self->tag( 'AS', 'AS:i:' . int($gff->score) );
    $self->tag( 'CQ', 'CQ:Z:' . join('',@cquals) );

    # The color string needs some work because the SAM format wants the
    # primer base (T for F3, G for R3) plus the full 35 colors but the gff
    # "g" attribute is the first base of the sequence plus 34 colors so
    # we need to recover the first color before converting to SAM.

    my @colors = split //, $gff->attrib('g');
    my $base1 = ( $gff->seqname =~ /F3$/ ) ? 'T' : 'G';
    my $base2 = shift @colors;
    unshift @colors, $base1, _bb2c( $base1, $base2 );
    $self->tag( 'CS', 'CS:Z:' . join('',@colors) );

    #print Dumper $gff, $self; exit;
}


sub MD {
    my $self = shift;
    my $seq  = shift;
    my $ref  = shift;

    my $md_str = '';
    my $ctr = 0;

    # Do a base-by-base compare on the read and reference sequences

    foreach my $i (0..(length($seq)-1)) {
        if (uc(substr( $seq, $i, 1 )) eq uc(substr( $ref, $i, 1 ))) {
            $ctr++;
        }
        else {
            if ($ctr > 0) {
                $md_str .= $ctr;
                $ctr = 0;
            }
            $md_str .= substr( $ref, $i, 1 );
        }
    }
    if ($ctr > 0) {
        $md_str .= $ctr;
    }

    return $md_str;
}


sub as_text {
    my $self = shift;

    return join( "\t", $self->qname,
                       $self->flag,
                       $self->rname,
                       $self->pos,
                       $self->mapq,
                       $self->cigar,
                       $self->mrnm,
                       $self->mpos,
                       $self->isize,
                       $self->seq,
                       $self->qual,
                       $self->tags_as_array )."\n";
}

1;
 
__END__


=head1 NAME

QCMG::IO::SamRecord - SAM record data container


=head1 SYNOPSIS

 use QCMG::IO::SamRecord;


=head1 DESCRIPTION

This module provides an interface for reading and writing SAM Files.


=head1 AUTHORS

John Pearson L<mailto:j.pearson@uq.edu.au>


=head1 VERSION

$Id: $


=head1 COPYRIGHT

This software is copyright 2010 by the Queensland Centre for Medical
Genomics.  All rights reserved.  This License is limited to, and you
may use the Software solely for, your own internal and non-commercial
use for academic and research purposes. Without limiting the foregoing,
you may not use the Software as part of, or in any way in connection with 
the production, marketing, sale or support of any commercial product or
service or for any governmental purposes.  For commercial or governmental 
use, please contact licensing\@qcmg.org.

In any work or product derived from the use of this Software, proper 
attribution of the authors as the source of the software or data must be 
made.  The following URL should be cited:

  http://bioinformatics.qcmg.org/software/

=cut
