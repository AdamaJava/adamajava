package QCMG::X_Mate::DNA_ISAS;

use strict;
use Object::InsideOut;
use QCMG::BaseClass::ISAS;
use File::Basename;
use Carp;

#parameter from configure file straiteway
my @objConf :Field :Arg('Name' => 'conf', 'Mandatory' => 1) :Get('objConf');
my @objTool :Field;

#push all collated file name into this array
my @outGeno :Field :Get(genome_collated);

sub _init :Init{ 	
	my ($self, $arg) = @_;
	my $conf = $objConf[$$self];
	$self->set(\@objTool, $objConf[$$self]->get_objTool );

	#created output file names -- collated files; one array of genome collated file and another array of genome collated file
	my $isas_genome = $objConf[$$self]->isas_genome;
        foreach my $a (@$isas_genome){
		my ($l, $m) = split(',', $a->global);
		my $f = $objConf[$$self]->output_dir . $objConf[$$self]->exp_name . ".geno.mers$l.collated";
                push @{$outGeno[$$self]}, $f;
        }
}

#methods:

sub recursive{
	my ($self, $f_forMap) = @_;
	
	#create a two dimention array to store recursive mapping parameters
	my @maps = ();
	my $array = $objConf[$$self]->map_lengths;
	@maps = sort{ $b <=> $a } @$array;

	my $l_last = $maps[0];
	my $f_nonMatch = $f_forMap->[0];
        $objTool[$$self]->Log_PROCESS("start recursive mapping...");
	for(my $i = 0; $i < scalar(@maps); $i ++){
		#chop tag
		my $l_chop = $l_last - $maps[$i];
		my $f_shorttag = $f_forMap->[$i];
		if($l_chop < 0){$objTool[$$self]->Log_DIED("can't chop tag from $l_last to $maps[$i] in sub DNAMapping::recursive")}
		if($l_chop > 0){
			$objTool[$$self]->Log_PROCESS("chopping tag from mers$l_last to mers$maps[$i]");
			$objTool[$$self]->chop_tag($f_nonMatch, $f_shorttag, $l_chop);
			$objTool[$$self]->Log_SUCCESS("chopped tag from mers$l_last to mers$maps[$i]");
		} 

		my $genome = $objConf[$$self]->isas_genome->[$i];
		my $objMap = QCMG::BaseClass::ISAS->new(
			'exp_name' =>$objConf[$$self]->exp_name,
			'output_dir' =>$objConf[$$self]->output_dir,
			'isas' =>$objConf[$$self]->isas,
			'database' =>$genome->database,
			'chr' => $genome->chr,
			'mode' => $genome->mode,
			'verbose' => $genome->verbose,
			'limit' =>$genome->limit,
			'filter' => $genome->filter,
			'global' => $genome->global,
			'file' => $f_shorttag,
		        'chrRename' => $genome->IndexRename,
			'objTool' => $objConf[$$self]->get_objTool
		);	
                $objMap->mapping;
                $objMap->collation;

                $f_nonMatch = $objMap->f_nonMatch;
                rename($objMap->f_collated, $outGeno[$$self]->[$i]);
                $l_last = $maps[$i];
	}

	$objTool[$$self]->Log_SUCCESS("recursive mapping is done, collated files are created");
}


1;

