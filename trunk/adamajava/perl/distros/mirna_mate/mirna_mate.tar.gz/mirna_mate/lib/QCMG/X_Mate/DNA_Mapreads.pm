package QCMG::X_Mate::DNA_Mapreads;

use strict;

use Object::InsideOut;
use QCMG::BaseClass::Mapping;
use QCMG::BaseClass::Tools;
use File::Basename;
use Carp;


#parameter from configure file straiteway
my @objConf :Field :Arg('Name' => 'conf', 'Mandatory' => 1);
my @objTool :Field;

#push all collated file name into this array
my @outGeno :Field :Get(genome_collated);


sub _init :Init{ 	
	my ($self, $arg) = @_;
	my $conf = $objConf[$$self];
	$self->set(\@objTool, $objConf[$$self]->get_objTool);

	#created output file name -- collated files
        my $array = $objConf[$$self]->recursive_maps;
        foreach my $a (@$array){
                my $f_geno = $objConf[$$self]->output_dir . $objConf[$$self]->exp_name . ".geno.$a.collated";
                push @{$outGeno[$$self]}, $f_geno;
        }
}

sub recursive{
	my ($self,$f_forMap) = @_;
	
	#create a two dimention array to store recursive mapping parameters
	my @maps = ();
	my $array = $objConf[$$self]->recursive_maps;
	foreach my $a (@$array){
		my @s_map = split(/\./, $a);
		push @maps, [@s_map];
	}
	
	@maps = sort{ $b->[0] <=> $a->[0] } @maps;


        my $l_last = $maps[0][0];
        my $f_nonMatch = $f_forMap->[0];


	for(my $i = 0; $i < scalar(@maps); $i ++){
		#chop tag
		my $l_chop = $l_last - $maps[$i][0];
		my $f_shorttag = $f_forMap->[$i];
		if($l_chop < 0){$objTool[$$self]->Log_DIED("can't chop tag from $l_last to $maps[$i][0] in sub DNAMapping::recursive")}
		if($l_chop > 0){
			$objTool[$$self]->Log_PROCESS("chopping tag from mers$l_last to mers$maps[$i][0]");
			$objTool[$$self]->chop_tag($f_nonMatch, $f_shorttag, $l_chop);
		} 

		#mapping &collate
		my $objMap = QCMG::BaseClass::Mapping->new(	
				'genomes' => $objConf[$$self]->genomes,
				'exp_name' => $objConf[$$self]->exp_name,
				'output_dir' => $objConf[$$self]->output_dir,
				'mapreads' => $objConf[$$self]->mapreads,
				'max_hits' =>  $objConf[$$self]->max_hits,
				'tag_file' => $f_shorttag,
				'mask' => $objConf[$$self]->mask,
				'tag_length' => $maps[$i][0],
				'mismatch' => $maps[$i][1],
				'adj_error' => $maps[$i][2],
				'objTool' => $objTool[$$self],

		);
	
		$objTool[$$self]->Log_PROCESS("mapping -- mers" . $maps[$i][0]);	
		$objMap->mapping;
		$objTool[$$self]->Log_PROCESS("collating tags -- mers" . $maps[$i][0]);	
		$objMap->collation;
		
		$f_nonMatch = $objMap->f_nonMatch;
		rename($objMap->f_collated, $outGeno[$$self]->[$i]);
		$l_last = $maps[$i][0];	
	}

	$objTool[$$self]->Log_SUCCESS("recursive mapping is done, collated files are created");

}

1;

=head1 NAME

DNAMapping  - A perl modules which call QCMG::BaseClass::Mapping recursivly

=head1 SYNOPSIS

  use DNAMapping;
  my $obj = DNAMapping->new('conf' => $objConf);
  $obj->recursive;

=head1 DESCRIPTION

This module is runing recursive mapping; This means it map tags,then passing mapped tag to a collated file and chop the nonmapped tag and map it again. This module require an reference of DNAConf module which contain all DNA mapping configuration (See detail in DNAConf module's documentation)

=head2 Methods

=over 2

=item * $obj->recursive;

This function call QCMG::BaseClass::Mapping, collate mapped tags and then chop non-mapped tags recursivly

=item * $obj->f_collated

return an reference of array, in which all collated file name is stored.

=back

=head1 AUTHOR

qinying Xu (Christina) (q.xu@imb.uq.edu.au)

=head1 COPYRIGHT

Copyright 2009 Grimmond Group, IMB, UQ, AU.  All rights reserved.

