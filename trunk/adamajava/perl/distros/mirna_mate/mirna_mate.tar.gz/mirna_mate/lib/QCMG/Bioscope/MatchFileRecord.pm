package QCMG::Bioscope::MatchFileRecord;

###########################################################################
#
#  Module:   QCMG::Bioscope:MatchFileRecord
#  Creator:  John V Pearson
#  Created:  2010-03-10
#
###########################################################################

use strict;
use warnings;

use Data::Dumper;

sub new {
    my $class = shift;
    my %params = @_;

    my $self  = { defline  => $params{defline},
                  sequence => $params{sequence},
                  verbose  => ($params{verbose} ? $params{verbose} : 0),
                };

    bless $self, $class;
}

sub verbose {
    my $self = shift;
    return $self->{verbose};
}

sub defline {
    my $self = shift;
    return $self->{defline};
}

sub sequence {
    my $self = shift;
    return $self->{sequence};
}

1;
__END__


=head1 NAME

QCMG::Bioscope::MatchFileRecord - Bioscope match file record


=head1 SYNOPSIS

 use QCMG::Bioscope::MatchFileRecord;

 my $rec = QCMG::Bioscope::MatchFileRecord->new(
               defline => '>seq1 my little sequence',
               seq     => 'ACGCATCAGCATCAGACTACGCGCATACAGC',
               verbose => 1 );


=head1 DESCRIPTION

This module provides an interface for reading Bioscope match files.

A match file contains multiple comment lines that document the
program(s) run to create the match file.


=head1 PUBLIC METHODS

=over

=item B<new()>

 my $ma = QCMG::Bioscope::MatchFile->new(
                filename => '300001_20100310_F3.ma',
                verbose  => 1 );  

A file must be supplied to this constructor although it can be a plain
text file (filename attribute) or a zipped file (zipfile attribute).

=item B<filename()>
 
 $ma->filename();

Returns the name of the match file loaded in this object.

=item B<verbose()>

 $ma->verbose();

Returns the verbose status for this object where 0 sets verbose off 
and any other value (traditionally 1) sets verbose mode on.

=item B<headers()>

 my @headers = $ma->headers();

Returns an array of the header lines read from the file.

=item B<next_record()>

 my $rec = $ma->next_record;

Returns an object of type QCMG::Bioscope::MatchFileRecord which contains
the next match file record.

=back


=head1 AUTHORS

=over

=item John Pearson L<mailto:j.pearson@uq.edu.au>

=back


=head1 VERSION

$Id: $


=head1 COPYRIGHT

This software is copyright 2010 by the Queensland Centre for Medical
Genomics. All rights reserved.  This License is limited to, and you
may use the Software solely for, your own internal and non-commercial
use for academic and research purposes. Without limiting the foregoing,
you may not use the Software as part of, or in any way in connection with 
the production, marketing, sale or support of any commercial product or
service or for any governmental purposes.  For commercial or governmental 
use, please contact licensing\@qcmg.org.

In any work or product derived from the use of this Software, proper 
attribution of the authors as the source of the software or data must be 
made.  The following URL should be cited:

  http://bioinformatics.qcmg.org/software/

=cut
