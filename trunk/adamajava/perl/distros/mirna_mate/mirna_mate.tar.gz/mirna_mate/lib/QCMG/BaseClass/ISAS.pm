package QCMG::BaseClass::ISAS;

use strict;
use Object::InsideOut;
use File::Basename;
use File::Spec::Functions qw( catdir ); 
use Carp;
use Parallel::ForkManager;
use constant {	TRUE => 'true', NUM_PARA => 5};

#Attr:
#parameters for whole mapping 
my @exp_name :Field :Arg('Name' => 'exp_name','Mandatory' => 1, 'Regexp' => qr/^exp_n[am]{1,2}e$/i);
my @output_dir :Field :Arg('Name' => 'output_dir','Mandatory' => 1, 'Regexp' => qr/^output[_]{1,2}dir$/i);
my @isas :Field :Arg('Name' => 'isas','Mandatory' => 1, 'Regexp' => qr/^isas$/i);

#parameters for run ISAS
my @database :Field :Arg('Name' => 'database', 'mandatory' => 1):Get(database);
my @chr :Field :Arg('Name' => 'chr', 'mandatory' => 1):Get('chr');  
my @mode :Field :Arg('Name' => 'mode', 'mandatory' => 1) :Default('2va') :Get(mode);
my @verbose :Field :Arg('Name' => 'verbose', 'mandatory' => 1) :Get(verbose) :Default(1);
my @limit :Field :Arg('Name' => 'limit', 'mandatory' => 1) :Get(limit) :Default(10);
my @filter :Field :Arg('Name' => 'filter', 'mandatory' => 1) :Get(filter):Default(0);
my @global :Field :Arg('Name' =>'global', 'mandatory' => 1) :Get(global);
my @file :Field :Arg('Name' => 'file', 'Mandatory' => 1, 'Regexp' => qr/^file$/i);
my @chrRename :Field :Arg('Name' => 'chrRename', 'Mandatory' => 1); #a hash

#to store all mapping outputs name from mapping method, which will be used for collation methods
my @f_mapped :Field :Get(f_mapped);
my @f_nonMatch : Field :Get(f_nonMatch);
my @f_collated :Field :Get(f_collated);
my @objTool :Field :Arg('Name' => 'objTool', 'Mandatory' => 1,  'Regexp' => qr/^objtool/i);

#methods
sub _init :Init{
	my ($self, $arg) = @_;

	my $f = $file[$$self];
        (my $mod = $mode[$$self]) =~ tr/[a-z]/[A-Z]/;
        $f .= ".Mode" . $mod;

	my ($l,$m) = split(',',$global[$$self]);
	if($l == 25){ $f .= ".Length$l"	}
	else{ $f .= ".Global$l-$m"	}

        $f .= "-Limit" . $limit[$$self];
        if($verbose[$$self] == 1) { $f .= "-NormalOutput"    }
        elsif($verbose[$$self] == 0){ $f .= "-NonVerbose"    }
        elsif($verbose[$$self] == 2){ $f .= "-UniqueOnly"    }

        if($filter[$$self] == 0){$f .= "-NoFilter.txt"}
        else{ $f .= "-FilterLevel" . $filter[$$self] . ".txt"    }

	$self->set(\@f_mapped, $f);

	$f =~ s/txt$/collated/;
	$self->set(\@f_collated, $f);

	$f = $output_dir[$$self].$exp_name[$$self] .".mers$l.nonMatch";
	$self->set(\@f_nonMatch, $f);

}

sub mapping{
	my ($self) = @_;
	
	#check log file, make sure any other paralled job are died
	$objTool[$$self]->check_died; 
	
	if( !(-e $file[$$self]) ) { $objTool[$$self]->Log_DIED("can't find reads file: $file[$$self]")  }
	
	#for example, after quality check may no qualified tag with mers35, but lots of qualified with mers30
	my $output = $f_mapped[$$self];
	if( -z $file[$$self] ){
		$objTool[$$self]->Log_WARNING("no reads in reads file: $file[$$self]!");
		open(OUT, ">$output") or $objTool[$$self]->Log_DIED("can't create mapping output file: $output!");
		close(OUT);
		return 1;
	}

	#run ISAS
	my @comm = ();
	push @comm, $isas[$$self] ." database=" . $database[$$self];
	push @comm, $isas[$$self] ." chr=" . $chr[$$self];
	push @comm, $isas[$$self] ." mode=" . $mode[$$self];
	push @comm, $isas[$$self] ." verbose=" . $verbose[$$self];
	push @comm, $isas[$$self] ." limit=" . $limit[$$self];
	push @comm, $isas[$$self] ." filter=" . $filter[$$self];
	push @comm, $isas[$$self] ." global=" . $global[$$self];

	
	for(my $i = 0; $i < scalar(@comm); $i ++){
		my $command = $comm[$i];
		system($command) == 0 or $objTool[$$self]->Log_DIED("Get failure return value during run ISAS, please retry command: $command");
		sleep(30);
	}
	&check_setting($self, $database[$$self], 'settings-colors.txt');
	$objTool[$$self]->check_died;

	my $command =  $isas[$$self] ." file=" . $file[$$self];
	my $rc = system($command);
	sleep(30);
	if($rc != 0){ $objTool[$$self]->Log_DIED("Get failure return value $rc during run ISAS, please retry command: $command"); return -1}

	#change output file name
	my @fTXT = <$output_dir[$$self]*.txt>;
	my $flag = 0;
	foreach my $f (@fTXT){
		if($f =~ m/Stats\.txt$/){ my $fNew = $f; $fNew =~ s/\.txt$//; rename($f, $fNew);$flag ++; next }
		if($f =~ m/$file[$$self]/ ){ my $fNew = $f; $fNew =~ s/\.txt$/\.ma/;  rename($f, $fNew); $self->set(\@f_mapped, $fNew);	 $flag ++; next	}	
	}
	if($flag != 2){$objTool[$$self]->Log_DIED("can't find ISAS mapped output, such as $f_mapped[$$self]; It might be ISAS died, please retry $command "); return -1}
		
}

sub collation{
	my  $self = shift;
	
	$objTool[$$self]->check_died; 
	#open output file
	open(COLLATED, ">$f_collated[$$self]" ) or $objTool[$$self]->Log_DIED("can't create collated file: $f_collated[$$self]");
	open(NON_MATCHED,"> $f_nonMatch[$$self]" ) or $objTool[$$self]->Log_DIED("can't create non-matched file: $f_nonMatch[$$self]");
	
	#get chromosome original name, if junction we name it as same as the junction index file
	#get a mapped file and start reading tag from this file
	open(MAP, $f_mapped[$$self]) or $objTool[$$self]->Log_DIED("can't open mapped file $f_mapped[$$self]");
	while(<MAP>){
		if(! m/^>/){ next }	
		chomp();
		my @maps = split(',');
		my $id = shift(@maps);
		my $seq = <MAP>;
		my $tatal = scalar(@maps);
		if($tatal == 0){ print NON_MATCHED  "$id\n$seq"; next 	}
		
		print COLLATED "$id\t$tatal";
		foreach my $m (@maps){
			my ($chr, $mm);
			if($m =~ m/\d+_/){  ($chr, $mm) = split('_',$m)	}
			else{$chr = 1; $mm = $m	}
			$chr = $chrRename[$$self]->{$chr};
			print COLLATED "\t$chr.$mm";
		}
		print COLLATED "\n$seq";
	}

	#close all files
	close(MAP);
	close(COLLATED);
	close(NON_MATCHED);
}

1;
sub check_setting{
	my ($self, $database, $f_setting) = @_;
	
	my $file = catdir($database, $f_setting);
	open(SET, $file) or $objTool[$$self]->Log_DIED("cannot open ISAS setting file: $file");
	my $flag = 0;
	while(my $line = <SET>){
		if($line =~ m/^\#/){next}
		chomp($line);
		my($value, $para) = split(",", $line);
		if($para =~ m/FirstChromosome/i){ if($chr[$$self] =~ m/^$value,\d+$/){ $flag ++ }else{$flag = -1}}
		elsif($para =~ m/LastChromosome/i){if($chr[$$self] =~ m/^\d+,$value$/){ $flag ++}else{$flag = -1}}
		elsif($para =~ m/Mode/i){if( $value == $mode[$$self]){ $flag ++ }else{$flag = -1}}
		elsif($para =~ m/Limit/i){if( $value == $limit[$$self]){ $flag ++ }else{$flag = -1}}
		elsif($para =~ m/ExtendedReadLength/i){if( $global[$$self] =~ m/^$value,\d+$/){ $flag ++ }else{$flag = -1}}
	#	elsif($para =~ m/ExtendedAllowedMismatches/i){if( $global[$$self] =~ m/^\d+,$value$/){ $flag ++ }else{$flag = -1}}
		elsif($para =~ m/VerboseOutput/i){if( $value == $verbose[$$self]){ $flag ++ }else{$flag = -1}}
		elsif($para =~ m/FilterLevel/i){if( $value == $filter[$$self]){ $flag ++ }else{$flag = -1}}

		if($flag == -1){ $objTool[$$self]->Log_DIED("wrong value in seting file: $file, see the line: $line"); return -1	}
	}
	
	if($flag != 7){ $objTool[$$self]->Log_DIED("Can't find some parameters in setting file: $file, which is listing in configure"); return -1	}
	else{ print "successfully saving setting into file: $file\n"}

	return 1;
}

=head1 NAME

Mapping  - A perl modules which call mapreads repeatly

=head1 SYNOPSIS

  use QCMG::BaseClass::ISAS;
  my $obj = QCMG::BaseClass::ISAS->new(%argv);
  $obj->mapping;
  $obj->collation;

=head1 DESCRIPTION

This module map tags to genomes which list on the hash table "genomes" elements and then collates all mapped tags into one file. Here we make an example to list all necessary arguments:

	my %argv = (

	);

Before it calls mapreads program, it will create related schema file according to above arguments.

=head2 Methods

=over 4

=item * $obj->mapping;

this function passes all arguments to mapreads and submit it to queueing system, it will wait until all mapping jobs are done.
 

input file which listed on argument "tag_file": eg. "/data/test.csfasta";

output file formart: "genome name" . "exp_name" .  "ma". "tag_length" . "$mismatch" . "$adj_error", eg.
                                "/data/chr1.test.ma.10.1.0 ,  "/data/chr2.test.ma.10.1.0

=item * $obj->collation( );

this function collated all mapped position from all mapped files (see QCMG::BaseClass::Mapping::mapping), if the total mapped position for a tag over max_hit, all these position will be throw away. it also report all nonmapped tags for next mappin loop.
example of input file: "/data/chr1.test.ma.10.1.0 ,  "/data/chr2.test.ma.10.1.0

        final output: "/data/test.ma.10.1.0.collated" , "/data/test.ma.10.1.0.nonMatch"

=item * $obj->f_nonMatch;

return the non mapped tag file which will be used on next mapping loop

=item * $obj->f_collated

return the collated file name.

=back

=head1 AUTHOR

qinying Xu (Christina) (q.xu@imb.uq.edu.au)

=head1 COPYRIGHT

Copyright 200999999999d Group, IMB, UQ, AU.  All rights reserved.


=head1 SEE ALSO

perl(1).

=cut

