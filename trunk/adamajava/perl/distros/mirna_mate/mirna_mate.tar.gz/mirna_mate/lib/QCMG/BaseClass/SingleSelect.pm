package QCMG::BaseClass::SingleSelect;

use strict;
use Object::InsideOut;

use constant { TRUE => "true", FALSE => "false"	};

#Attr:
my @output_dir :Field :Arg('Name' => 'output_dir','Mandatory' => 1, 'Regexp' => qr/^output[_]{1,2}dir$/i);
my @exp_name :Field :Arg('Name' => 'exp_name','Mandatory' => 1, 'Regexp' => qr/^exp_n[am]{1,2}e$/i);
my @max_mismatch :Field :Arg('Name' => 'max_mismatch', 'Mandatory' => 1);
my @chr_names :Field :Arg('Name' => 'chr_names', 'Mandatory' => 1);
my @expect_strand :Field :Arg('Name' => 'expect_strand', 'Mandatory' => 1);
my @objTool :Field :Arg('Name' => 'objTool', 'Mandatory' => 1,  'Regexp' => qr/^objtool/i);
my @f_singles :Field :Get(f_singles); #an array of output files which reporting each single selected position
my @fPos_forWig :Field :Get(out_Positive);
my @fNeg_forWig :Field :Get(out_Negative);

#methods
sub _init :Init{

	my ($self, $arg ) = @_;
	
	foreach my $chr (@{$chr_names[$$self]}){
		#create SiM file
		my $f = $output_dir[$$self] . "$chr." . $exp_name[$$self] . ".SIM";
		push @{$f_singles[$$self]}, $f;

		#convert the output formart for wigplot
                my $output = $output_dir[$$self]."$chr.".$exp_name[$$self].".for_wig.positive";
                push @{$fPos_forWig[$$self]},  $output;
                $output = $output_dir[$$self]."$chr.".$exp_name[$$self].".for_wig.negative";
                push @{$fNeg_forWig[$$self]},  $output;
        }
}

sub SingleSelect{

	my ($self, $ref_collated) = @_;
	
	#create output files
	my %outs = ();
	foreach my $chr (@{$chr_names[$$self]}){	
		my $f = $output_dir[$$self] . "$chr."  . $exp_name[$$self] . ".SIM";
		open(my $fh, ">$f") or $objTool[$$self]->Log_DIED("can't create output for single selection -- $f");
		$outs{$chr} = $fh;
	}
	foreach my $f (@$ref_collated){
		open(IN, $f) or $objTool[$$self]->Log_DIED("can't open collated file: $f in Class SingleSelct");
		while(my $line = <IN>){
			if( $line !~ m/^\>/){next}
			chomp($line);
			my @matches = split(/\t/,$line);
			my $id = shift(@matches);
			my $freq =  shift(@matches);
			my $selected = FALSE;

			if($expect_strand[$$self] eq "0"){ $selected = &EqualSiM($self,\@matches) }
			else{	$selected = &StrandSiM($self, \@matches, $expect_strand[$$self])  }
			if($selected eq FALSE){ next }
		
			#report the single selected position
			my ($chr, $pos, $mis) = split(/\./, $selected);
			my $seq = <IN>;
			my $fh = $outs{$chr};
			print $fh "$id,$pos.$mis\n$seq";
		}
		close(IN);
	}

	foreach my $key (keys %outs){ close( $outs{$key} )	}

}

sub afSelect{

        my ($self) = @_;

        my $pm = new Parallel::ForkManager( 5 );
        #parallel to prepare pre wig files
        foreach my $f (@{$f_singles[$$self]}){
                $pm->start and next;
                open(IN, $f) or $objTool[$$self]->Log_DIED(" can't open file $f in sub QCMG::BaseClass::SingleSelect::afSelect\n");
                (my $fp = $f) =~ s/SIM/for_wig\.positive/;
                open(POS,">$fp") or $objTool[$$self]->Log_DIED(" can't open file $fp in sub QCMG::BaseClass::SingleSelect::afSelect\n");
                (my $fn = $f) =~ s/SIM/for_wig\.negative/;
                open(NEG,">$fn") or $objTool[$$self]->Log_DIED(" can't open file $fn in sub QCMG::BaseClass::SingleSelect::afSelect\n");

                while(<IN>){
			if(! /^\>/){ next }
                        chomp();
			my ($id, $map) = split(/\,/);
			my ($pos, $mis) = split(/\./, $map);
			my $seq = <IN>;
			chomp($seq);
			my $l = length($seq) - 1;

                        if( ($pos >= 0) ){my $start = $pos;	my $end = $start + $l -1;	print POS "$start\t$end\t1\n"}
                        else{my $end = abs($pos); my $start = $end -$l + 1;  print NEG "$start\t$end\t1\n"}
                }
                close(IN);
                close(NEG);
                close(POS);

                #sort output file by start position
                my $f_tmp = "$f.tme";
                system("sort -n -k1 $fp > $f_tmp");
                unlink($fp);
                rename($f_tmp, $fp );

                system("sort -n -k1 $fn > $f_tmp");
                unlink($fn);
                rename($f_tmp, $fn );

                $pm->finish;
        }

        #wait all pre_wig files are created
        $pm->wait_all_children;
}
1;
#create single selection file ingor tag's strand
#the output file formart is "tagid\t$position.$mismatch\n$sequence\n"
sub EqualSiM{
	my ($self, $matches) = @_;

				
	#get the multiposition with smallest mismatch value
	my $min_mis = $max_mismatch[$$self];
	my @selects = ();
	foreach my $match (@$matches){
		my ($chr, $pos, $mis) = split(/\./, $match);
		if($mis == $min_mis ){ push @selects, $match }
		elsif($mis < $min_mis){	@selects = (); push @selects, $match;  $min_mis = $mis }
	}
	
	my $select = FALSE;
	if( scalar(@selects) == 1 ){	$select = $selects[0]	}
#	elsif(scalar(@selects) == 0 ){	$objTool[$$self]->Log_DIED("can't find matched position from @$matches ")}
	
	return $select;
}

#single selection with high poriosity for specified strand tag
sub StrandSiM{

	my ($self, $matches, $expect_strand) = @_;


	#classify all mismathed position by strand, initial them refer to empty array
	my %exp_mis = ();
	my %non_mis = ();
	for(my $i = 0; $i <= $max_mismatch[$$self]; $i ++){ $exp_mis{$i} = [] ; $non_mis{$i} = [] }

        #get the multiposition with smallest mismatch value
        foreach my $match (@$matches){
	        my ($chr, $pos, $mis) = split(/\./, $match);
		if( (($pos >= 0) && ($expect_strand eq "+" )) || (($pos < 0) && ($expect_strand eq "-"))  ){ push @{$exp_mis{$mis}}, $match }
		else{ push @{ $non_mis{$mis} }, $match }
        }
			
	#search single mapping position from expect strand position	
	my $select = FALSE;
	for(my $i = 0; $i <= $max_mismatch[$$self]; $i ++){ 
		my $ref = $exp_mis{$i};
		if(scalar(@$ref) == 1){ 
			$select = shift(@$ref); last 	}  
	}
	if($select eq FALSE){
		for(my $i = 0; $i <= $max_mismatch[$$self]; $i ++){
			my $ref = $non_mis{$i};
			if(scalar(@$ref) == 1){ $select = $ref->[0]; last }  
		}
	}

	return $select;
}

=head1 NAME

SingleSelect  - A perl modules which call MuMRescueLite.py

=head1 SYNOPSIS

  use QCMG::BaseClass::SingleSelect;
  my $obj = QCMG::BaseClass::SingleSelect->new(%argv);
  my $collated = ["/data/test.ma.35.3.0.collated", "/data/test.ma.30.3.0.collated"];
  $obj->SingleSelect($collated);
  $obj->afSelect;

=head1 DESCRIPTION
This module select the single position for all multi-mapped tag. 

	        'exp_name' => "test"
	        'output_dir' => "/data/",
	        'mapreads' => "/data/mapreads",
	        'max_mismatch' => 3,
		'chr_names' => ["chr1", "chr2"],
		'expect_strand' => 0,
	        'objTool' => $objTool,
	);

=head2 Methods

=over 4

=item * $obj->SingleSelect;

This function read the collated file, select the single mapping position. There are two ways to select the position according to specified strand.
If you set "0" to "expect_strand" on the initialization step, this function will select the mapping position with the lowest mismatch value disregarding the strand. Else if you set "+" or "-" to "expect_strand", it will select position with that strand on high priority. See example below:

>tagA	chr1.100.1	chr2.200.2	chr2.-300.1
T2000122222332100251
>tagB	chr1.200.3	chr3.105.1	chr4.-500.2
T2000123210202222332


If the expect strand is "+", the single position is "chr1.100.1" for tagA , "chr3.105.1" for tagB; Else if the expect strand is "-", for "chr2.-300.1" for tagA, "chr4.-500.2" for tagB; If the expect strand is "0", it ignor the strand and select nothing for tagA, select "chr3.105.1" for tagB.

the output of this function is the single file. on above example with positive strand, there are two outputs: "/data/chr1.test.SIM" and "/data/chr3.test.SIM". the content of the first output will be:
>tagA	100.1
T2000122222332100251


=item * $obj->afSelect;

This function classify the single file by strand and chromosome name, and the convert th format to suit to wiggle plot. 

=item * $obj->out_Positive;

The output of all single selcted tags with positive strand, such as, "/data/chr1.test.for_wig.positive", "/data/chrX.test.for_wig.positive".

=item * $obj->out_Negative

The output of all single tags with negative strand, such as, "/data/chr1.test.for_wig.negative", "/data/chrX.test.for_wig.negative".

=back

=head1 AUTHOR

qinying Xu (Christina) (q.xu@imb.uq.edu.au)

=head1 COPYRIGHT

Copyright 2009 Group, IMB, UQ, AU.  All rights reserved.


=head1 SEE ALSO

perl(1).

=cut

