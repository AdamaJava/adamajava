# time_stamp
# factorial
# median_of_sorted_array

sub time_stamp {
  my ($d,$t);
  my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);
        $year += 1900;
        $mon++;
        $d = sprintf("%4d-%2.2d-%2.2d",$year,$mon,$mday);
        $t = sprintf("%2.2d:%2.2d:%2.2d",$hour,$min,$sec);
        return($d,$t);
}


sub factorial {
    my ($n) = @_;

    if($n == 0){
	return 1;
    }
    elsif($n == 1){
	return $n;
    }
    else {
	return $n * factorial($n-1);
    }
}


sub median_of_sorted_array {

    my(@array) = @_;

    my($length_of_array, $median);

    # Length of Array
    $length_of_array = scalar @array;
    
    #If the number of values is even, the median is the average of the two middle values
    if( ($length_of_array % 2) == 0 ) {
	# Looking for the average of the values at positions n/2 and n/2 + 1
	$median = ( $array[($length_of_array/2) - 1] + $array[(($length_of_array/2)+1) - 1] ) / 2;
    }
    #If the number of values is odd, the median is the middle value 
    else{
	# Looking for the value at position (n+1)/2
	$median = $array[( ($length_of_array+1)/2 ) - 1];
    }
    
    return $median;
}


1;
