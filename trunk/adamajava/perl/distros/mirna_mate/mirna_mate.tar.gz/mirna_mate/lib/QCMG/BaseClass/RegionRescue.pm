package QCMG::BaseClass::RegionRescue;

use Object::InsideOut;
use strict;
use Parallel::ForkManager;

use constant{num_parallel => 4};


#Attr:
#parameters for whole mapping 
my @output_dir :Field :Arg('Name' => 'output_dir','Mandatory' => 1, 'Regexp' => qr/^output[_]{1,2}dir$/i);
my @exp_name :Field :Arg('Name' => 'exp_name','Mandatory' => 1, 'Regexp' => qr/^exp_n[am]{1,2}e$/i);
my @max_hits :Field :Arg('Name' => 'max_hits','Regexp' => qr/^max[_]{0,2}hit[s]{0,1}$/i, 'Default' => 10);
my @max_mismatch :Field :Arg('Name' => 'max_mismatch', 'Mandatory' => 1);
my @chr_names :Field :Arg('Name' => 'chr_names', 'Mandatory' => 1);
my @rescue_window :Field :Arg('Name' => 'rescue_window', 'Mandatory' => 1);
my @objTool :Field :Arg('Name' => 'objTool', 'Mandatory' => 1,  'Regexp' => qr/^objtool/i);

my @fPos_forWig :Field :Get(out_Positive);
my @fNeg_forWig :Field :Get(out_Negative);


#Methods:
sub _init :Init{
	my ($self, $arg) = @_;

	#report all final output file name
	my $chrs = $chr_names[$$self];
        for my $chr (@$chrs){
                my $output = $output_dir[$$self]."$chr.".$exp_name[$$self].".for_wig.positive";
                push @{$fPos_forWig[$$self]},  $output;
                $output = $output_dir[$$self]."$chr.".$exp_name[$$self].".for_wig.negative";
                push @{$fNeg_forWig[$$self]},  $output;
        }

}


sub main{
        my ($self, $ref_collated) = @_;
        $objTool[$$self]->Log_PROCESS("Runing MuMRescueLite ...");


        #reporting all multimpping position with lowest mismatch value using MuMRescueLite input formart
        my $f_forRescue = $output_dir[$$self] . $exp_name[$$self] . ".geno.for_rescue";
        &preRescue($self, $ref_collated, $f_forRescue);

        #run MuMRESCUELite
        my $f_rescued = "$f_forRescue.weighted";
        &Rescue($self, $f_forRescue, $f_rescued);

        #classify output from MuMRESCUELite by chromosome - for wigplot.
        &afRescue($self, $f_rescued);
        $objTool[$$self]->Log_SUCCESS("Finished MuMRescueLite!");
}

sub preRescue{

        my ($self, $inRef, $output) = @_;
        open(RESCUED, ">$output") or $objTool[$$self]->Log_DIED("can't create $output for sub preRescue \n " );

        foreach my $f_collated (@$inRef){
                open(IN, $f_collated) or $objTool[$$self]->Log_DIED("Can't open collated file -- $f_collated in sub preRescue");
                while(my $line = <IN>){
                          #only read read tag id line
                          if($line !~ /^>/){ next       }
                          chomp($line);
                          my @matches = split(/\t/,$line);
                          my $tagid = shift(@matches);
                          my $total = shift(@matches);
                          # throw this non mapped or over mapped tag
                          if( $total == 0 || $total > $max_hits[$$self] ){ next}

                          # initialize this tag's mismatch 
                          my %mis = ();
                          for(my $i =0; $i <= $max_mismatch[$$self];$i ++){$mis{$i} = 0}
                          # count this tag matched times at each mismatch value
                          foreach my $p (@matches){
                                my ($chr,$position,$mismatch) = split(/\./,$p);
                                $mis{$mismatch} ++;
                          }

                          # get the matched position with lowest mismatch value, throw other matched postion 
                          my $s_mismatch = -1;
                          for(my $i = 0; $i <= $max_mismatch[$$self]; $i ++){ if($mis{$i} > 0){ $s_mismatch = $i; last}     }
                          if($s_mismatch == -1){$objTool[$$self]->Log_DIED( "error on <COLLATED> ($line) \n"); last}
                          if($s_mismatch == -1){$objTool[$$self]->Log_WARNING("error on <COLLATED> ($line) \n");next}

                          #report the selected position to 
                          my $seq = <IN>;
                          chomp($seq);
                          my $mers = length($seq);

                          foreach my $m (@matches){
                                my ($chr,$position,$mismatch) = split(/\./,$m);
                                if($mismatch != $s_mismatch){ next }
                                if($position < 0){
                                   my $end = abs($position );
                                   my $start = $end - $mers + 1;
                                   print RESCUED  "$tagid\t$mis{$s_mismatch}\t$chr\t-\t$start\t$end\t1\n";
                          	}
	                          else{
                                   my $start = $position;
                                   my $end = $start + $mers - 1;
                                   print RESCUED "$tagid\t$mis{$s_mismatch}\t$chr\t+\t$start\t$end\t1\n";
        	                }
			}#end foreach
                }#end while

                close(IN);
        }#end foreach

        close(RESCUED);
}

#run MuMRESCUELite
sub Rescue{

        my ($self, $inMuM, $outMuM) = @_;

        #Create shell script to run MuMRescueLite
        my $fSH = $output_dir[$$self] . "RunLite.sh";
        my $fOK = $output_dir[$$self] . "RunLite.ok";
        my $ferr = $output_dir[$$self] . "RunLite.err";
        my $fout = $output_dir[$$self] . "RunLite.out";
        my $fid = $output_dir[$$self] . "RunLite.id";
        my $ftrace = $output_dir[$$self]."traceJob.txt";

        open(SH, ">$fSH") or $objTool[$$self]->Log_DIED("can't create shell script file for running MuMRescueLite");
        my $comm = "python -i " . $rescue_program[$$self] . "  $inMuM $outMuM  ".  $rescue_window[$$self];
        print SH $comm;
        #when MuMRescueLite compelete successfule, it will print 0 to $fOK
        print SH "\necho \$\? \> $fOK";
        close(SH);
#debug
#system("sh $fSH");

        #wait job to be compelete on the queuing system
        $comm = "qsub -l walltime=12:00:00 -o $fout -e $ferr $fSH > $fid";
        my $rc = system($comm);
        my %q_file = ($fOK => $rc);
        $objTool[$$self]->wait_for_queue(\%q_file);

        #get queue id and trace the resource usage
#        open(ID, $fid) or $objTool[$$self]->Log_DIED("can't open $fid in sub Rescue");
#       my $line = <ID>;
#        close(ID);
#        if($line =~ m/^(\d+)\.\w+/){ system("tracejob $1 > $ftrace")}
#        else{$objTool[$$self]->Log_DIED("can't get job id from file $fid in sub Rescue")}

	unlink($fSH);
	unlink($fOK);
	unlink($ferr);
	unlink($fout);
	unlink($fid);
}


sub afRescue{

        my ($self, $f_rescued) = @_;

        my $pm = new Parallel::ForkManager( 5 );
        my $chromosomes = $chr_names[$$self];
        #parallel to prepare pre wig files
        foreach my $chr (@$chromosomes){
                $pm->start and next;
                open(IN, $f_rescued) or $objTool[$$self]->Log_DIED(" can't open file $f_rescued\n");
                my $fp = $output_dir[$$self] . "$chr." . $exp_name[$$self]. ".for_wig.positive";
                open(POS,">$fp") or $objTool[$$self]->Log_DIED(" can't open file $fp\n");
                my $fn = $output_dir[$$self] . "$chr." . $exp_name[$$self]. ".for_wig.negative";
                open(NEG,">$fn") or $objTool[$$self]->Log_DIED(" can't open file $fn\n");
                while(<IN>){
                        chomp();
                        my ($id,$numPos,$chr_rescue,$strand, $start,$end,$freq,$score) = split(/\t/);
                        if($chr eq $chr_rescue){
                                if( ($strand eq "+") && ($score > 0) ){print POS "$start\t$end\t$score\n"}
                                elsif( ($strand eq "-") && ($score > 0) ){print NEG "$start\t$end\t$score\n"}
                        }
                }
                close(IN);
                close(NEG);
                close(POS);

                #sort output file by start position
                my $f_tmp = $output_dir[$$self] . "$chr.forWig.tmp";
                system("sort -n -k1 $fp > $f_tmp");
		unlink($fp);
                rename($f_tmp, $fp );

                system("sort -n -k1 $fn > $f_tmp");
		unlink($fn);
                rename($f_tmp, $fn );

                $pm->finish;
        }

        #wait all pre_wig files are created
        $pm->wait_all_children;

}
1;

=head1 NAME

MuMRescueLite  - A perl modules which call MuMRescueLite.py

=head1 SYNOPSIS

  use QCMG::BaseClass::MuMRescueLite;
  my $obj = QCMG::BaseClass::MuMRescutLite->new(%argv);
  $obj->main;

=head1 DESCRIPTION
This module calls the MuMRescueLite.py program. 

	        'exp_name' => "test"
	        'output_dir' => "/data/",
	        'mapreads' => "/data/mapreads",
	        'max_hits' =>  10,
	        'max_mismatch' => 1,
		'chr_names' => ["chr1", "chr2"],
		'rescue_program' => "/data/MuMRescutLite.py",
		'rescue_window' => 200,
	        'objTool' => $objTool,
	);

=head2 Methods

=over 4

=item * $obj->main;

There are three main step in this function. First, this module reads the collated file and convert the formart; Second,it pass new formated file to MuMRescueLite.py which will run on queuing system, it will wait here until the rescue program is finished. Finally, it classify the rescue output by mapping strand and chromosome name; and  convert the output format to suit wigplot module.


=item * $obj->out_Positive;

The output of all rescued tags with positive strand, such as, "/data/chr1.test.for_wig.positive", "/data/chrX.test.for_wig.positive".

=item * $obj->out_Negative

The output of all rescued tags with negative strand, such as, "/data/chr1.test.for_wig.negative", "/data/chrX.test.for_wig.negative".

=back

=head1 AUTHOR

qinying Xu (Christina) (q.xu@imb.uq.edu.au)

=head1 COPYRIGHT

Copyright 2009 Group, IMB, UQ, AU.  All rights reserved.


=head1 SEE ALSO

perl(1).

=cut

