package QCMG::IO::VCFReader;

###########################################################################
#
#  Module:   QCMG::IO::VCFReader
#  Creator:  John V Pearson
#  Created:  2009-01-26
#
#  Reads Variant Call Format (VCF) files as specified by the 1000
#  Genomes project.
#
#  $Id: $
#
###########################################################################

use Data::Dumper;
use Carp qw( confess );

use QCMG::IO::VCFRecord;
use QCMG::IO::VCFFile;

sub new {
    my $class = shift;
    my %params = @_;

    confess "VCFReader:new() requires a filename or zipname parameter" 
        unless ( (exists $params{filename} and defined $params{filename}) or
                 (exists $params{zipname} and defined $params{zipname}) );

    my $self = { filename        => ( $params{filename} ?
                                      $params{filename} : 0),
                 zipname         => ( $params{zipname} ?
                                      $params{zipname} : 0),
                 version         => '2',
                 headers         => {},
                 valid_headers   => {},
                 record_count    => 0,
                 verbose         => ($params{verbose} ?
                                     $params{verbose} : 0),
               };

    bless $self, $class;

    # If there a zipname, we use it in preference to filename.  We only
    # process one so if both are specified, the zipname wins.

    if ( $params{zipname} ) {
        my $fh = IO::Zlib->new( $params{zipname}, 'r' );
        confess 'Unable to open ', $params{zipname}, "for reading: $!"
            unless defined $fh;
        $self->filename( $params{zipname} );
        $self->filehandle( $fh );
    }
    elsif ( $params{filename} ) {
        my $fh = IO::File->new( $params{filename}, 'r' );
        confess 'Unable to open ', $params{filename}, "for reading: $!"
            unless defined $fh;
        $self->filename( $params{filename} );
        $self->filehandle( $fh );
    }

    $self->process_header_line;

    return $self;
}


sub filename {
    my $self = shift;
    return $self->{filename} = shift if @_;
    return $self->{filename};
}


sub filehandle {
    my $self = shift;
    return $self->{filehandle} = shift if @_;
    return $self->{filehandle};
}


sub verbose {
    my $self = shift;
    return $self->{verbose};
}


sub record_count {
    my $self = shift;
    return $self->{record_count};
}


sub _valid_headers {
    my $self = shift;
    return $self->{valid_headers};
}


sub _headers {
    my $self = shift;
    return $self->{headers};
}


sub _incr_record_count {
    my $self = shift;
    return $self->{record_count}++;
}


sub next_record {
    my $self = shift;

    # Read lines, checking for and processing any headers
    # and only return once we have a record

    while (1) {
        my $line = $self->filehandle->getline();
        # Catch EOF
        return undef if (! defined $line);

        if ($self->verbose) {
            # Print progress messages for every 1M records
            $self->_incr_record_count;
            print( $self->record_count, ' VCF records processed: ',
                   localtime().'', "\n" )
                if $self->record_count % 100000 == 0;
        }
        my $vcf = QCMG::IO::VCF->new( $line );
        print $vcf->debug if ($self->verbose > 1);
        return $vcf;
    }
}


sub process_header_line {
    my $self = shift;

    my @expected_headers = ( 'ProbeID',
                             'TargetID',
                             'GeneSymbol',
                             'GeneName',
                             'Accessions',
                             'Description' );

    my $headers = $self->filehandle->getline;
    chomp $headers;
    my @headers = split /\t/, $headers;
    my $problems = 0;
    
    foreach my $expected_header (@expected_headers) {
        my $actual_header = shift @headers;
        unless ( $expected_header =~ m/$actual_header/i) {
            warn "Header mismatch - ",
                 "expected: $expected_header, found: $actual_header";
                $problems++;
        }
    }
    die "Unable to continue until all header problems have been resolved"
       if ($problems > 0);

}



sub next_record_as_sam {
    my $self = shift;

    my $gff = $self->next_record;
    return undef unless defined $gff;
    my $sam = Sam->new( gff => $gff );
    return $sam;
}

1;

__END__


=head1 NAME

QCMG::IO::VCFReader - VCF file IO


=head1 SYNOPSIS

 use QCMG::IO::VCFReader;
  
 my $vcf = QCMG::IO::VCFReader->new( file => 'sample1.vcf' );


=head1 DESCRIPTION

This module provides an interface for reading and writing VCF Files.


=head1 PUBLIC METHODS

=over

=item B<new()>

 my $vcf = QCMG::IO::VCFReader->new( file => 'sample1.vcf' );

=item B<debug()>

 $vcf->debug(1);

Flag to force increased warnings.  Defaults to 0 (off);

=head2 browser_lines

 $ct->browser_lines( 'position' => 'chr1:81388000-95184580',
                     'full'     => 'all', 
                     'pix'      => '1000' );

=item B<slurp()>

 my $vcf_file = $vcf->slurp();

This method should only be called immediately after a call to new().  It
will take all remaining records in the VCF file and read them into a
QCMG::IO::VCFFile object.  This is particularly useful when merging
multiple vcf files.

=back


=head1 AUTHORS

=over
=item John Pearson, L<mailto:j.pearson@uq.edu.au>
=back


=head1 VERSION

$Id: $


=head1 COPYRIGHT

This software is copyright 2010 by the Queensland Centre for Medical
Genomics. All rights reserved.  This License is limited to, and you
may use the Software solely for, your own internal and non-commercial
use for academic and research purposes. Without limiting the foregoing,
you may not use the Software as part of, or in any way in connection with 
the production, marketing, sale or support of any commercial product or
service or for any governmental purposes.  For commercial or governmental 
use, please contact licensing\@qcmg.org.

In any work or product derived from the use of this Software, proper 
attribution of the authors as the source of the software or data must be 
made.  The following URL should be cited:

  http://bioinformatics.qcmg.org/software/

=cut
