package QCMG::X_Mate::RNA_ISAS;

use strict;
use Object::InsideOut 'QCMG::X_Mate::DNA_ISAS';
use QCMG::BaseClass::ISAS;
use File::Basename;
use Carp;

#push all collated file name into this array
my @outJunc :Field :Get(junction_collated);

sub _init :Init{ 	
	my ($self, $arg) = @_;
	
#	$self->set(\@objConf, $self->DNA_ISAS::objConf);
	my $objConf = $self->DNA_ISAS::objConf;

	#created output file names -- collated files; one array of genome collated file and another array of genome collated file
	my $isas_genome = $objConf->isas_genome;
        foreach my $a (@$isas_genome){
		my ($l, $m) = split(',', $a->global  );
		my $f = $objConf->output_dir . $objConf->exp_name . ".junc.mers$l.collated";
                push @{$outJunc[$$self]}, $f;
        }
}

#methods:
sub recursive{
	my ($self, $f_forMap) = @_;
	
	my $objConf = $self->DNA_ISAS::objConf;
	my $objTool = $objConf->get_objTool;
	#create a two dimention array to store recursive mapping parameters
	my @maps = ();
	my $array = $objConf->map_lengths;
	@maps = sort{ $b <=> $a } @$array;

	my $l_last = $maps[0];
	my $f_nonMatch = $f_forMap->[0];
        $objTool->Log_PROCESS("start mapping...");
	for(my $i = 0; $i < scalar(@maps); $i ++){
		#chop tag
		my $l_chop = $l_last - $maps[$i];
		my $f_shorttag = $f_forMap->[$i];
		if($l_chop < 0){$objTool->Log_DIED("can't chop tag from $l_last to $maps[$i] in sub DNAMapping::recursive")}
		if($l_chop > 0){
			$objTool->Log_PROCESS("chopping tag from mers$l_last to mers$maps[$i]");
			$objTool->chop_tag($f_nonMatch, $f_shorttag, $l_chop);
			#deleted the nonMatch file as it is not the file for mapping
			unlink($f_nonMatch);
		}
 
		#genome mapping
		my $genome = $objConf->isas_genome->[$i];
		my %para =(
			'exp_name' =>$objConf->exp_name,
			'output_dir' =>$objConf->output_dir,
			'isas' =>$objConf->isas,
			'database' =>$genome->database,
			'chr' => $genome->chr,
			'mode' => $genome->mode,
			'verbose' => $genome->verbose,
			'limit' =>$genome->limit,
			'filter' => $genome->filter,
			'global' => $genome->global,
			'file' => $f_shorttag,
			'chrRename' => $genome->IndexRename,
			'objTool' => $objConf->get_objTool
		);	
		my $objMap = QCMG::BaseClass::ISAS->new( %para );
                $objMap->mapping;
                $objMap->collation;
                rename($objMap->f_collated, $self->DNA_ISAS::genome_collated->[$i]);

		#junction mapping
		$para{'database'} = $objConf->isas_junc->[$i]->database;
		$para{'chr'} = $objConf->isas_junc->[$i]->chr;
		$para{'file'} = $objMap->f_nonMatch;
		my @array = ("chrj");
		$para{'chrRename'} = $objConf->isas_junc->[$i]->IndexRename; 
		$objMap= QCMG::BaseClass::ISAS->new( %para );
		$objMap->mapping;
		$objMap->collation;
                rename($objMap->f_collated, $outJunc[$$self]->[$i]);

                $l_last = $maps[$i];
		$f_nonMatch = $objMap->f_nonMatch;
	}
	$objTool->Log_SUCCESS("recursive mapping is done, collated files are created");
}

1;

